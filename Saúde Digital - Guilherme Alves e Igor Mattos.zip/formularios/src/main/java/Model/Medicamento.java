/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;


public class Medicamento {
    private String nomeMedicamento;
    private String principioAtivo;
    private String formaFarmaceutica;
    private String dosagem;
    private String indicacoes;
    private String contraIndicacoes;
    private String codigoIdentificacao;

    // Construtor
    public Medicamento(String nomeMedicamento, String principioAtivo, String formaFarmaceutica, String dosagem, String indicacoes, String contraIndicacoes, String codigoIdentificacao) {
        this.nomeMedicamento = nomeMedicamento;
        this.principioAtivo = principioAtivo;
        this.formaFarmaceutica = formaFarmaceutica;
        this.dosagem = dosagem;
        this.indicacoes = indicacoes;
        this.contraIndicacoes = contraIndicacoes;
        this.codigoIdentificacao = codigoIdentificacao;
    }

    // Getters
    public String getNomeMedicamento() {
        return nomeMedicamento;
    }

    public String getPrincipioAtivo() {
        return principioAtivo;
    }

    public String getFormaFarmaceutica() {
        return formaFarmaceutica;
    }

    public String getDosagem() {
        return dosagem;
    }

    public String getIndicacoes() {
        return indicacoes;
    }

    public String getContraIndicacoes() {
        return contraIndicacoes;
    }

    public String getCodigoIdentificacao() {
        return codigoIdentificacao;
    }
}


