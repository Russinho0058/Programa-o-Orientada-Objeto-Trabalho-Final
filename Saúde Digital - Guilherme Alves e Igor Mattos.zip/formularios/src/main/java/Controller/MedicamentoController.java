package Controller;

import Model.Medicamento;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import util.DatabaseConnection; // Certifique-se de que o caminho está correto

public class MedicamentoController {

    public void adicionarMedicamento(Medicamento medicamento) {
        String sql = "INSERT INTO medicamentos (nome_medicamento, principio_ativo, forma_farmaceutica, dosagem, indicacoes, contra_indicacoes, codigo_identificacao) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, medicamento.getNomeMedicamento());
            statement.setString(2, medicamento.getPrincipioAtivo());
            statement.setString(3, medicamento.getFormaFarmaceutica());
            statement.setString(4, medicamento.getDosagem());
            statement.setString(5, medicamento.getIndicacoes());
            statement.setString(6, medicamento.getContraIndicacoes());
            statement.setString(7, medicamento.getCodigoIdentificacao());

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Medicamento cadastrado com sucesso!");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar medicamento: " + e.getMessage());
        }
    }

    public List<Medicamento> getMedicamentos() {
        List<Medicamento> listaMedicamentos = new ArrayList<>();
        String sql = "SELECT * FROM medicamentos";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                String nomeMedicamento = resultSet.getString("nome_medicamento");
                String principioAtivo = resultSet.getString("principio_ativo");
                String formaFarmaceutica = resultSet.getString("forma_farmaceutica");
                String dosagem = resultSet.getString("dosagem");
                String indicacoes = resultSet.getString("indicacoes");
                String contraIndicacoes = resultSet.getString("contra_indicacoes");
                String codigoIdentificacao = resultSet.getString("codigo_identificacao");

                Medicamento medicamento = new Medicamento(nomeMedicamento, principioAtivo, formaFarmaceutica, dosagem, indicacoes, contraIndicacoes, codigoIdentificacao);
                listaMedicamentos.add(medicamento);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao buscar medicamentos: " + e.getMessage());
        }

        return listaMedicamentos;
    }

}