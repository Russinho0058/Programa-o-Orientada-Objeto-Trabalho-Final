/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Paciente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import util.DatabaseConnection;

public class PacienteController {

    public void adicionarPaciente(Paciente paciente) {
        String sql = "INSERT INTO pacientes (nome, data_nascimento, tipo_sanguineo, plano_saude, telefone, descricao, medicamento) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, paciente.getNome());
            statement.setString(2, paciente.getDataNascimento());
            statement.setString(3, paciente.getTipoSanguineo());
            statement.setString(4, paciente.getPlanoSaude());
            statement.setString(5, paciente.getTelefone());
            statement.setString(6, paciente.getDescricao());
            statement.setString(7, paciente.getMedicamento());

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Paciente cadastrado com sucesso!");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar paciente: " + e.getMessage());
        }
    }

    public List<Paciente> getPacientes() {
        List<Paciente> listaPacientes = new ArrayList<>();
        String sql = "SELECT * FROM pacientes";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                String nome = resultSet.getString("nome");
                String dataNascimento = resultSet.getString("data_nascimento");
                String tipoSanguineo = resultSet.getString("tipo_sanguineo");
                String planoSaude = resultSet.getString("plano_saude");
                String telefone = resultSet.getString("telefone");
                String descricao = resultSet.getString("descricao");
                String medicamento = resultSet.getString("medicamento");
                
                Paciente paciente = new Paciente(nome, dataNascimento, tipoSanguineo, planoSaude, telefone, descricao, medicamento);
                listaPacientes.add(paciente);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao buscar pacientes: " + e.getMessage());
        }
        if (listaPacientes.isEmpty()) {
            System.out.println("Nenhum paciente encontrado.");
        }

        return listaPacientes;
    }
}