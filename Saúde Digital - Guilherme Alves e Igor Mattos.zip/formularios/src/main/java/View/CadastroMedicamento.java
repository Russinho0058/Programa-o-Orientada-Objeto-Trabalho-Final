/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import Model.Medicamento;
import Controller.MedicamentoController;
import javax.swing.JOptionPane;

    
public class CadastroMedicamento extends javax.swing.JFrame {
    MedicamentoController controller = new MedicamentoController();
    
    public CadastroMedicamento() {
        initComponents();
    }
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tfTotal2 = new javax.swing.JTextField();
        textoCabecalhoSomatorio = new javax.swing.JLabel();
        nomeMedicamento = new javax.swing.JLabel();
        lblsegundoNumero = new javax.swing.JLabel();
        campoNomeMedicamento = new javax.swing.JTextField();
        campoPrincipioAtivo = new javax.swing.JTextField();
        campoIndicacoes = new javax.swing.JTextField();
        botaoCadastrarMedicamento = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        campoDosagem = new javax.swing.JTextField();
        campoContraindicacoes = new javax.swing.JTextField();
        campoCodigo = new javax.swing.JTextField();
        campoFormaFarmaceutica = new javax.swing.JTextField();
        BtnVerTabela = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(802, 534));
        getContentPane().setLayout(null);

        textoCabecalhoSomatorio.setFont(new java.awt.Font("Perpetua Titling MT", 0, 36)); // NOI18N
        textoCabecalhoSomatorio.setText("Cadastro de Medicamento");
        getContentPane().add(textoCabecalhoSomatorio);
        textoCabecalhoSomatorio.setBounds(140, 20, 550, 60);

        nomeMedicamento.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        nomeMedicamento.setText("Nome do medicamento:");
        getContentPane().add(nomeMedicamento);
        nomeMedicamento.setBounds(27, 100, 147, 20);

        lblsegundoNumero.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblsegundoNumero.setText("Princípio ativo:");
        getContentPane().add(lblsegundoNumero);
        lblsegundoNumero.setBounds(480, 100, 89, 25);

        campoNomeMedicamento.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(campoNomeMedicamento);
        campoNomeMedicamento.setBounds(180, 100, 223, 30);

        campoPrincipioAtivo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(campoPrincipioAtivo);
        campoPrincipioAtivo.setBounds(580, 100, 200, 30);

        campoIndicacoes.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(campoIndicacoes);
        campoIndicacoes.setBounds(181, 234, 600, 60);

        botaoCadastrarMedicamento.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        botaoCadastrarMedicamento.setText("Cadastrar");
        botaoCadastrarMedicamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoCadastrarMedicamentoActionPerformed(evt);
            }
        });
        getContentPane().add(botaoCadastrarMedicamento);
        botaoCadastrarMedicamento.setBounds(200, 430, 170, 60);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("Forma farmacêutica:");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(50, 150, 123, 20);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Indicações:");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(110, 230, 70, 27);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Dosagem recomendada:");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(27, 197, 148, 20);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setText("Contraindicações:");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(70, 320, 107, 20);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setText("Código de Identificação:");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(427, 139, 146, 30);

        campoDosagem.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(campoDosagem);
        campoDosagem.setBounds(180, 190, 600, 30);

        campoContraindicacoes.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(campoContraindicacoes);
        campoContraindicacoes.setBounds(183, 310, 600, 80);

        campoCodigo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(campoCodigo);
        campoCodigo.setBounds(580, 140, 41, 30);

        campoFormaFarmaceutica.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(campoFormaFarmaceutica);
        campoFormaFarmaceutica.setBounds(183, 150, 220, 30);

        BtnVerTabela.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        BtnVerTabela.setText("Ver Tabela");
        BtnVerTabela.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnVerTabelaActionPerformed(evt);
            }
        });
        getContentPane().add(BtnVerTabela);
        BtnVerTabela.setBounds(470, 430, 150, 60);

        jLabel6.setIcon(new javax.swing.ImageIcon("C:\\Users\\valer\\OneDrive\\Área de Trabalho\\formularios\\formularios\\src\\main\\resources\\imagens\\Logo.jpg")); // NOI18N
        getContentPane().add(jLabel6);
        jLabel6.setBounds(10, 0, 790, 540);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botaoCadastrarMedicamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoCadastrarMedicamentoActionPerformed
       try {
            String nome = campoNomeMedicamento.getText();
            String principioAtivo = campoPrincipioAtivo.getText();
            String formaFarmaceutica = campoFormaFarmaceutica.getText();
            String dosagem = campoDosagem.getText();
            String indicacoes = campoIndicacoes.getText();
            String contraIndicacoes = campoContraindicacoes.getText();
            String codigoIdentificacao = campoCodigo.getText(); // Alterado para String

            Medicamento medicamento = new Medicamento(nome, principioAtivo, formaFarmaceutica, dosagem, indicacoes, contraIndicacoes, codigoIdentificacao);
            controller.adicionarMedicamento(medicamento);

            JOptionPane.showMessageDialog(this, "Medicamento cadastrado com sucesso!");
            limparCampos();
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Código de Identificação deve ser um número.", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_botaoCadastrarMedicamentoActionPerformed

    private void BtnVerTabelaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnVerTabelaActionPerformed
        TabelaMedicamento tabela = new TabelaMedicamento(controller); // Passa a instância existente
        tabela.setVisible(true);     
    }//GEN-LAST:event_BtnVerTabelaActionPerformed
     private void limparCampos() {
        campoNomeMedicamento.setText("");
        campoPrincipioAtivo.setText("");
        campoFormaFarmaceutica.setText("");
        campoDosagem.setText("");
        campoIndicacoes.setText("");
        campoContraindicacoes.setText("");
        campoCodigo.setText("");
    }
     
    /**
     * @param args the command line arguments
     */
public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroMedicamento().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnVerTabela;
    private javax.swing.JButton botaoCadastrarMedicamento;
    private javax.swing.JTextField campoCodigo;
    private javax.swing.JTextField campoContraindicacoes;
    private javax.swing.JTextField campoDosagem;
    private javax.swing.JTextField campoFormaFarmaceutica;
    private javax.swing.JTextField campoIndicacoes;
    private javax.swing.JTextField campoNomeMedicamento;
    private javax.swing.JTextField campoPrincipioAtivo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel lblsegundoNumero;
    private javax.swing.JLabel nomeMedicamento;
    private javax.swing.JLabel textoCabecalhoSomatorio;
    private javax.swing.JTextField tfTotal2;
    // End of variables declaration//GEN-END:variables
}
