/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import Controller.PacienteController;
import Model.Paciente;
import javax.swing.table.DefaultTableModel;

public class TabelaPacientes extends javax.swing.JFrame {
 PacienteController controller;

    public TabelaPacientes(PacienteController controller) {
        initComponents();
        this.controller = controller;
        carregarTabela();
    
}   

   private void carregarTabela() {
        DefaultTableModel modelo = (DefaultTableModel) tabela1.getModel();
        modelo.setRowCount(0);

        for (Paciente paciente : controller.getPacientes()) {
            modelo.addRow(new Object[]{
                paciente.getNome(),
                paciente.getDataNascimento(),
                paciente.getTipoSanguineo(),
                paciente.getPlanoSaude(),
                paciente.getTelefone(),
                paciente.getDescricao(),
                paciente.getMedicamento()
            });
        }
   }
   public void updateTable(String nome, String descricao, String medicamento) { 
        DefaultTableModel modelo = (DefaultTableModel) tabela1.getModel();
        modelo.addRow(new Object[]{nome, descricao, medicamento}); // Adiciona uma nova linha com a descrição
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        textoCabecalho = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabela1 = new javax.swing.JTable();
        btnCarregar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(921, 519));
        getContentPane().setLayout(null);

        textoCabecalho.setFont(new java.awt.Font("Perpetua Titling MT", 0, 36)); // NOI18N
        textoCabecalho.setText("Dados da Ultima Consulta");
        getContentPane().add(textoCabecalho);
        textoCabecalho.setBounds(160, 30, 553, 50);

        tabela1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome Completo", "Data de Nascimento", "Tipo Sanguíneo", "Plano de Saúde", "Telefone", "Descrição", "Receitado"
            }
        ));
        jScrollPane1.setViewportView(tabela1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(40, 100, 855, 295);

        btnCarregar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnCarregar.setText("Carregar Tabela");
        btnCarregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarregarActionPerformed(evt);
            }
        });
        getContentPane().add(btnCarregar);
        btnCarregar.setBounds(350, 430, 170, 60);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\valer\\OneDrive\\Área de Trabalho\\formularios\\formularios\\src\\main\\resources\\imagens\\Logo.jpg")); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 940, 520);

        pack();
    }// </editor-fold>//GEN-END:initComponents
 
    private void btnCarregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarregarActionPerformed
        carregarTabela();
    }//GEN-LAST:event_btnCarregarActionPerformed

    /**
     * @param args the command line arguments
     */
   public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TabelaPacientes(new PacienteController()).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCarregar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabela1;
    private javax.swing.JLabel textoCabecalho;
    // End of variables declaration//GEN-END:variables
}
