/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import Controller.MedicamentoController;
import Controller.PacienteController;
import util.ImageLoader;
        
public class TelaInicial extends javax.swing.JFrame {


    public TelaInicial() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        textoCabecalho = new javax.swing.JLabel();
        btnCadastroPaciente = new javax.swing.JButton();
        btnConsultaMedicamento = new javax.swing.JButton();
        btnCadastroMedicamento = new javax.swing.JButton();
        btnUltimaConsulta = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(778, 515));
        getContentPane().setLayout(null);

        textoCabecalho.setFont(new java.awt.Font("Perpetua Titling MT", 0, 36)); // NOI18N
        textoCabecalho.setText("Saúde Digital");
        getContentPane().add(textoCabecalho);
        textoCabecalho.setBounds(260, 20, 330, 70);

        btnCadastroPaciente.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnCadastroPaciente.setText("Cadastro de Pacientes");
        btnCadastroPaciente.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnCadastroPaciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastroPacienteActionPerformed(evt);
            }
        });
        getContentPane().add(btnCadastroPaciente);
        btnCadastroPaciente.setBounds(440, 110, 220, 65);

        btnConsultaMedicamento.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnConsultaMedicamento.setText("Consulta de Medicamentos");
        btnConsultaMedicamento.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnConsultaMedicamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConsultaMedicamentoActionPerformed(evt);
            }
        });
        getContentPane().add(btnConsultaMedicamento);
        btnConsultaMedicamento.setBounds(70, 230, 280, 70);

        btnCadastroMedicamento.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnCadastroMedicamento.setText("Cadastro de Medicamentos");
        btnCadastroMedicamento.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnCadastroMedicamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCadastroMedicamentoActionPerformed(evt);
            }
        });
        getContentPane().add(btnCadastroMedicamento);
        btnCadastroMedicamento.setBounds(70, 110, 280, 65);

        btnUltimaConsulta.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnUltimaConsulta.setText("Dados de Ultima Consulta");
        btnUltimaConsulta.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnUltimaConsulta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUltimaConsultaActionPerformed(evt);
            }
        });
        getContentPane().add(btnUltimaConsulta);
        btnUltimaConsulta.setBounds(70, 350, 280, 65);

        jButton1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jButton1.setText("Ficha de Consulta");
        jButton1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(440, 230, 220, 70);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\valer\\OneDrive\\Área de Trabalho\\formularios\\formularios\\src\\main\\resources\\imagens\\Logo.jpg")); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 780, 520);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCadastroPacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastroPacienteActionPerformed
        CadastroPaciente telaCadastroPaciente = new CadastroPaciente();
        telaCadastroPaciente.setVisible(true);
    }//GEN-LAST:event_btnCadastroPacienteActionPerformed

    private void btnConsultaMedicamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConsultaMedicamentoActionPerformed
        MedicamentoController controller = new MedicamentoController();
        TabelaMedicamento tbMedicamento = new TabelaMedicamento(controller);
        tbMedicamento.setVisible(true);
    }//GEN-LAST:event_btnConsultaMedicamentoActionPerformed

    private void btnCadastroMedicamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastroMedicamentoActionPerformed
        CadastroMedicamento telaCadastroMedicamento = new CadastroMedicamento();
        telaCadastroMedicamento.setVisible(true);
    }//GEN-LAST:event_btnCadastroMedicamentoActionPerformed

    private void btnUltimaConsultaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUltimaConsultaActionPerformed
        PacienteController controller = new PacienteController();    
        TabelaPacientes tabelaPacientes = new TabelaPacientes(controller);
        tabelaPacientes.setVisible(true);
    }//GEN-LAST:event_btnUltimaConsultaActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        PacienteController controller = new PacienteController();    
        ConsultaPaciente consultaPacientes = new ConsultaPaciente(controller);
        consultaPacientes.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
         try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaInicial.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaInicial().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastroMedicamento;
    private javax.swing.JButton btnCadastroPaciente;
    private javax.swing.JButton btnConsultaMedicamento;
    private javax.swing.JButton btnUltimaConsulta;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel textoCabecalho;
    // End of variables declaration//GEN-END:variables
}
