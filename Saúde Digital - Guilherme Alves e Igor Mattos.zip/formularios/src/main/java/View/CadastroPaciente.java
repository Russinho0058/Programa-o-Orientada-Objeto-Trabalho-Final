    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import Model.Paciente;
import Controller.PacienteController;
import javax.swing.JOptionPane;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CadastroPaciente extends javax.swing.JFrame {

    PacienteController controller = new PacienteController();

    public CadastroPaciente() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        textoCabecalhoSomatorio = new javax.swing.JLabel();
        nome = new javax.swing.JLabel();
        lbldata = new javax.swing.JLabel();
        campoNome = new javax.swing.JTextField();
        tfData = new javax.swing.JTextField();
        tfTelefone = new javax.swing.JTextField();
        btnCadastro = new javax.swing.JButton();
        lbltipo = new javax.swing.JLabel();
        lbltelefone = new javax.swing.JLabel();
        lblplano = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jComboBox2 = new javax.swing.JComboBox<>();
        botaoVerTabelaActionPerformed = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(750, 437));
        getContentPane().setLayout(null);

        textoCabecalhoSomatorio.setFont(new java.awt.Font("Perpetua Titling MT", 0, 36)); // NOI18N
        textoCabecalhoSomatorio.setText("Cadastro de Paciente");
        getContentPane().add(textoCabecalhoSomatorio);
        textoCabecalhoSomatorio.setBounds(140, 30, 470, 43);

        nome.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        nome.setText("Nome completo:");
        getContentPane().add(nome);
        nome.setBounds(30, 100, 101, 30);

        lbldata.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbldata.setText("Data de Nascimento:");
        getContentPane().add(lbldata);
        lbldata.setBounds(290, 200, 127, 30);

        campoNome.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(campoNome);
        campoNome.setBounds(140, 100, 450, 30);

        tfData.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfData);
        tfData.setBounds(430, 200, 160, 30);

        tfTelefone.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tfTelefone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfTelefoneActionPerformed(evt);
            }
        });
        getContentPane().add(tfTelefone);
        tfTelefone.setBounds(130, 200, 115, 30);

        btnCadastro.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnCadastro.setText("Cadastrar");
        btnCadastro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoCadastrarActionPerformed(evt);
            }
        });
        getContentPane().add(btnCadastro);
        btnCadastro.setBounds(150, 310, 150, 60);

        lbltipo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbltipo.setText("Tipo sanguíneo:");
        getContentPane().add(lbltipo);
        lbltipo.setBounds(30, 150, 96, 30);

        lbltelefone.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbltelefone.setText("Telefone:");
        getContentPane().add(lbltelefone);
        lbltelefone.setBounds(70, 200, 60, 30);

        lblplano.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblplano.setText("Plano de saúde:");
        getContentPane().add(lblplano);
        lblplano.setBounds(320, 150, 96, 30);

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-" }));
        jComboBox1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(jComboBox1);
        jComboBox1.setBounds(140, 152, 72, 30);

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Amil", "Bradesco Saúde", "Hapvida", "Unimed", "SulAmérica Saúde", "NotreDame Intermédica", "Porto Seguro Saúde", "Prevent Senior", "Santa Helena Saúde", "Assim Saúde" }));
        jComboBox2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(jComboBox2);
        jComboBox2.setBounds(430, 150, 161, 30);

        botaoVerTabelaActionPerformed.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        botaoVerTabelaActionPerformed.setText("Resumo de Cadastro");
        botaoVerTabelaActionPerformed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoVerTabelaActionPerformedActionPerformed(evt);
            }
        });
        getContentPane().add(botaoVerTabelaActionPerformed);
        botaoVerTabelaActionPerformed.setBounds(370, 310, 196, 60);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\valer\\OneDrive\\Área de Trabalho\\formularios\\formularios\\src\\main\\resources\\imagens\\Logo.jpg")); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, -4, 720, 440);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botaoCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoCadastrarActionPerformed
    
    String nome = campoNome.getText();
        String dataNascimento = tfData.getText();
        String tipoSanguineo = jComboBox1.getSelectedItem().toString();
        String planoSaude = jComboBox2.getSelectedItem().toString();
        String telefone = tfTelefone.getText();
        String dataFormatada = null;
        SimpleDateFormat formatoEntrada = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat formatoSaida = new SimpleDateFormat("dd/MM/yyyy");

        try {
            Date data = formatoEntrada.parse(dataNascimento);
            dataFormatada = formatoSaida.format(data);
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(this, "Data inválida. Use o formato DD/MM/YYYY.");
            return;
        }
        
        String medicamento = "";
        Paciente paciente = new Paciente(nome, dataFormatada, tipoSanguineo, planoSaude, telefone, "", medicamento);
        controller.adicionarPaciente(paciente);

        JOptionPane.showMessageDialog(this, "Paciente cadastrado com sucesso!");
        limparCampos();
    }//GEN-LAST:event_botaoCadastrarActionPerformed

    private void botaoVerTabelaActionPerformedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoVerTabelaActionPerformedActionPerformed
        ConsultaPaciente consulta = new ConsultaPaciente(controller);
        consulta.setVisible(true);

    }//GEN-LAST:event_botaoVerTabelaActionPerformedActionPerformed

    private void tfTelefoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfTelefoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfTelefoneActionPerformed

    private void limparCampos() {
        campoNome.setText("");
        tfData.setText("");
        tfTelefone.setText("");
        jComboBox1.setSelectedIndex(0);
        jComboBox2.setSelectedIndex(0);
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroPaciente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botaoVerTabelaActionPerformed;
    private javax.swing.JButton btnCadastro;
    private javax.swing.JTextField campoNome;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lbldata;
    private javax.swing.JLabel lblplano;
    private javax.swing.JLabel lbltelefone;
    private javax.swing.JLabel lbltipo;
    private javax.swing.JLabel nome;
    private javax.swing.JLabel textoCabecalhoSomatorio;
    private javax.swing.JTextField tfData;
    private javax.swing.JTextField tfTelefone;
    // End of variables declaration//GEN-END:variables
}
