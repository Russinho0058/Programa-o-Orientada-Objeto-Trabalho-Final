    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

import Controller.PacienteController;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;

public class ConsultaPaciente extends JFrame {
    
    private PacienteController controller;

    public ConsultaPaciente(PacienteController controller) {
        this.controller = controller; // Inicializa o controlador
        initComponents();
        loadPacientes();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        textoCabecalhoSomatorio = new javax.swing.JLabel();
        nome = new javax.swing.JLabel();
        lbldata = new javax.swing.JLabel();
        exibirPaciente = new javax.swing.JButton();
        lbltipo = new javax.swing.JLabel();
        lbltelefone = new javax.swing.JLabel();
        lblplano = new javax.swing.JLabel();
        campoNome = new javax.swing.JComboBox<>();
        tipoSanguineo = new javax.swing.JTextField();
        tfData = new javax.swing.JTextField();
        tfTelefone = new javax.swing.JTextField();
        dbPlano = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tfDescricao = new javax.swing.JTextArea();
        lblDescricao = new javax.swing.JLabel();
        btnSalvar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        tfmedicamento = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(609, 501));
        getContentPane().setLayout(null);

        textoCabecalhoSomatorio.setFont(new java.awt.Font("Perpetua Titling MT", 0, 36)); // NOI18N
        textoCabecalhoSomatorio.setText("Consulta de Paciente");
        getContentPane().add(textoCabecalhoSomatorio);
        textoCabecalhoSomatorio.setBounds(70, 23, 470, 50);

        nome.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        nome.setText("Selecione o Paciente:");
        getContentPane().add(nome);
        nome.setBounds(20, 110, 130, 20);

        lbldata.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbldata.setText("Data de Nascimento:");
        getContentPane().add(lbldata);
        lbldata.setBounds(20, 150, 127, 25);

        exibirPaciente.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        exibirPaciente.setText("Resumir");
        exibirPaciente.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        exibirPaciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botaoCadastrarActionPerformed(evt);
            }
        });
        getContentPane().add(exibirPaciente);
        exibirPaciente.setBounds(130, 420, 130, 50);

        lbltipo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbltipo.setText("Tipo sanguíneo:");
        getContentPane().add(lbltipo);
        lbltipo.setBounds(270, 150, 96, 20);

        lbltelefone.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lbltelefone.setText("Telefone:");
        getContentPane().add(lbltelefone);
        lbltelefone.setBounds(310, 190, 54, 20);

        lblplano.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblplano.setText("Plano de saúde:");
        getContentPane().add(lblplano);
        lblplano.setBounds(50, 190, 100, 20);

        campoNome.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(campoNome);
        campoNome.setBounds(150, 110, 380, 22);

        tipoSanguineo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tipoSanguineo);
        tipoSanguineo.setBounds(370, 150, 156, 18);

        tfData.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tfData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfDataActionPerformed(evt);
            }
        });
        getContentPane().add(tfData);
        tfData.setBounds(150, 150, 87, 18);

        tfTelefone.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(tfTelefone);
        tfTelefone.setBounds(370, 190, 101, 18);

        dbPlano.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(dbPlano);
        dbPlano.setBounds(150, 190, 94, 18);

        tfDescricao.setColumns(20);
        tfDescricao.setRows(5);
        tfDescricao.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jScrollPane1.setViewportView(tfDescricao);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(100, 260, 420, 84);

        lblDescricao.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblDescricao.setText("Descrição de Sintomas:");
        getContentPane().add(lblDescricao);
        lblDescricao.setBounds(220, 230, 160, 20);

        btnSalvar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnSalvar.setText("Salvar");
        btnSalvar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        btnSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalvarActionPerformed(evt);
            }
        });
        getContentPane().add(btnSalvar);
        btnSalvar.setBounds(350, 420, 130, 50);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("Medicamento receitado:");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(20, 370, 160, 30);

        tfmedicamento.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tfmedicamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfmedicamentoActionPerformed(evt);
            }
        });
        getContentPane().add(tfmedicamento);
        tfmedicamento.setBounds(180, 372, 340, 30);

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\valer\\OneDrive\\Área de Trabalho\\formularios\\formularios\\src\\main\\resources\\imagens\\Logo.jpg")); // NOI18N
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 0, 610, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents
private void loadPacientes() {
    try {
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/sistema_saude", "root", "37139337xD#");
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT nome FROM pacientes");

        while (rs.next()) {
            campoNome.addItem(rs.getString("nome"));
        }

        rs.close();
        stmt.close();
        conn.close();
    } catch (Exception e) {
        e.printStackTrace();
    }
}
    private void botaoCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botaoCadastrarActionPerformed
         String nomePaciente = (String) campoNome.getSelectedItem();
        if (nomePaciente != null) {
            try {
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/sistema_saude", "root", "37139337xD#");
                PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM pacientes WHERE nome = ?");
                pstmt.setString(1, nomePaciente);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    // Carregar dados do paciente
                    tfData.setText(rs.getString("data_nascimento"));
                    tipoSanguineo.setText(rs.getString("tipo_sanguineo"));
                    dbPlano.setText(rs.getString("plano_saude"));
                    tfTelefone.setText(rs.getString("telefone"));
                } else {
                    JOptionPane.showMessageDialog(this, "Paciente não encontrado.", "Aviso", JOptionPane.INFORMATION_MESSAGE); 
                }
                rs.close();
                pstmt.close();
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Erro ao buscar dados do paciente.", "Erro", JOptionPane.ERROR_MESSAGE);          
            }
        }
    }//GEN-LAST:event_botaoCadastrarActionPerformed

    private void tfDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfDataActionPerformed

    }//GEN-LAST:event_tfDataActionPerformed

    private void btnSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalvarActionPerformed
    String nomePaciente = (String) campoNome.getSelectedItem();
    String descricaoSintomas = tfDescricao.getText();
    String medicamentoReceitado = tfmedicamento.getText();

    if (nomePaciente != null) {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/sistema_saude", "root", "37139337xD#");
            String updateQuery = "UPDATE pacientes SET descricao = ?, medicamento = ? WHERE nome = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(updateQuery)) {
                pstmt.setString(1, descricaoSintomas);
                pstmt.setString(2, medicamentoReceitado);
                pstmt.setString(3, nomePaciente);
                int rowsAffected = pstmt.executeUpdate();

                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(this, "Descrição e medicamento salvos com sucesso!", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                    
                    // Redirecionar para a tabela de pacientes
                    TabelaPacientes tabelaPacientes = new TabelaPacientes(controller);
                    tabelaPacientes.setVisible(true);
                    this.dispose(); // Fecha a tela atual
                } else {
                    JOptionPane.showMessageDialog(this, "Nenhum registro atualizado. Verifique se o paciente existe.", "Aviso", JOptionPane.WARNING_MESSAGE);
                }
            }
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erro ao salvar descrição do paciente.", "Erro", JOptionPane.ERROR_MESSAGE);          
        }
    }

    }//GEN-LAST:event_btnSalvarActionPerformed

    private void tfmedicamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfmedicamentoActionPerformed
        
    }//GEN-LAST:event_tfmedicamentoActionPerformed
public static void main(String[] args) {
    SwingUtilities.invokeLater(() -> {
        PacienteController controller = new PacienteController(); 
        ConsultaPaciente view = new ConsultaPaciente(controller); 
        view.setVisible(true);
    });
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnSalvar;
    private javax.swing.JComboBox<String> campoNome;
    private javax.swing.JTextField dbPlano;
    private javax.swing.JButton exibirPaciente;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lblDescricao;
    private javax.swing.JLabel lbldata;
    private javax.swing.JLabel lblplano;
    private javax.swing.JLabel lbltelefone;
    private javax.swing.JLabel lbltipo;
    private javax.swing.JLabel nome;
    private javax.swing.JLabel textoCabecalhoSomatorio;
    private javax.swing.JTextField tfData;
    private javax.swing.JTextArea tfDescricao;
    private javax.swing.JTextField tfTelefone;
    private javax.swing.JTextField tfmedicamento;
    private javax.swing.JTextField tipoSanguineo;
    // End of variables declaration//GEN-END:variables
}