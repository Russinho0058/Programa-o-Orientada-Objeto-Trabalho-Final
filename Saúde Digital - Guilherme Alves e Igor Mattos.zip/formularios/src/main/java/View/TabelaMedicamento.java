/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

    import Controller.MedicamentoController;
    import Model.Medicamento;
    import javax.swing.table.DefaultTableModel;

public class TabelaMedicamento extends javax.swing.JFrame {
 MedicamentoController controller;

    public TabelaMedicamento(MedicamentoController controller) {
    initComponents();
    this.controller = controller;
    carregarTabela();
}   

   private void carregarTabela() {
        DefaultTableModel modelo = (DefaultTableModel) tabelaMedicamentos.getModel();
        modelo.setRowCount(0);

        for (Medicamento medicamento : controller.getMedicamentos()) {
            modelo.addRow(new Object[]{
                medicamento.getNomeMedicamento(),
                medicamento.getPrincipioAtivo(),
                medicamento.getFormaFarmaceutica(),
                medicamento.getDosagem(),
                medicamento.getIndicacoes(),
                medicamento.getContraIndicacoes(),
                medicamento.getCodigoIdentificacao()
            });
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tabelaMedicamentos = new javax.swing.JTable();
        btnCarregar2 = new javax.swing.JButton();
        textoCabecalho = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1035, 524));
        getContentPane().setLayout(null);

        tabelaMedicamentos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Nome do Medicamento", "Princípio Ativo", "Forma", "Dosagem", "Indicações", "Contraindicações", "Código"
            }
        ));
        jScrollPane1.setViewportView(tabelaMedicamentos);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(20, 90, 990, 334);

        btnCarregar2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnCarregar2.setText("Carregar Tabela");
        btnCarregar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCarregar2ActionPerformed(evt);
            }
        });
        getContentPane().add(btnCarregar2);
        btnCarregar2.setBounds(460, 450, 160, 50);

        textoCabecalho.setFont(new java.awt.Font("Perpetua Titling MT", 0, 36)); // NOI18N
        textoCabecalho.setText("Medicamentos cadastrados");
        getContentPane().add(textoCabecalho);
        textoCabecalho.setBounds(250, 20, 571, 50);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\valer\\OneDrive\\Área de Trabalho\\formularios\\formularios\\src\\main\\resources\\imagens\\Logo.jpg")); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 1040, 520);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCarregar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarregar2ActionPerformed
        carregarTabela();
    }//GEN-LAST:event_btnCarregar2ActionPerformed

    /**
     * @param args the command line arguments
     */
     public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TabelaMedicamento(new MedicamentoController()).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCarregar2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabelaMedicamentos;
    private javax.swing.JLabel textoCabecalho;
    // End of variables declaration//GEN-END:variables
}
