CREATE DATABASE IF NOT EXISTS sistema_saude;

USE sistema_saude;

   CREATE TABLE IF NOT EXISTS medicamentos (
    codigo_identificacao INT PRIMARY KEY,
    nome_medicamento VARCHAR(255),
    principio_ativo VARCHAR(255),
    forma_farmaceutica VARCHAR(255),
    dosagem VARCHAR(255),
    indicacoes VARCHAR(255),
    contra_indicacoes VARCHAR(255)
);


CREATE TABLE IF NOT EXISTS pacientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    data_nascimento DATE NOT NULL,
    tipo_sanguineo VARCHAR(3) NOT NULL,
    plano_saude VARCHAR(255) NOT NULL,
    telefone VARCHAR(15)
);

ALTER TABLE pacientes
ADD COLUMN descricao TEXT;